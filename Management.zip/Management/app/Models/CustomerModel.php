<?php 
namespace App\Models;
use CodeIgniter\Model;
class CustomerModel extends Model
{
    protected $table = 'customer';
    protected $primaryKey = 'cid';
    
    protected $allowedFields = ['mid','customer_name','customer_email','customer_contact','created_at','updated_at'];
}