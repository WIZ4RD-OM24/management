<?php 
namespace App\Models;  
use CodeIgniter\Model;
  
class ManagerModel extends Model{
    protected $table = 'manager';
    protected $primaryKey = 'mid';
    protected $allowedFields = [
        'manager_name',
        'manager_email',
        'manager_password',
        'funds',
        'created_at',
        'updated_at',
        'contact'
    ];
}