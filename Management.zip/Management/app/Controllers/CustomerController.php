<?php 
namespace App\Controllers;  
use CodeIgniter\Controller;
use App\Models\CustomerModel;
  
class CustomerController extends Controller
{
    // show users list
    public function index(){
        $CustomerModel = new CustomerModel();
        $data['users'] = $CustomerModel->orderBy('cid', 'DESC')->findAll();
        return view('list_customer', $data);
    }
   
    // add user form
    public function create(){
        return view('add_customer');
    }
    // update user data
    public function update(){
        $CustomerModel = new CustomerModel();
        $id = $this->request->getVar('id');
        $data = [
            'customer_name' => $this->request->getVar('name'),
            'customer_email'  => $this->request->getVar('email'),
            'customer_contact' => $this->request->getVar('contact')
        ];
        $CustomerModel->update($id, $data);
        return $this->response->redirect(site_url('/users-list'));
    }
    // show single user
    public function singleUser($id = null){
        $CustomerModel = new CustomerModel();
        $data['user_obj'] = $CustomerModel->where('cid', $id)->first();
        return view('edit_customer', $data);
    }
    // insert data
    public function store() {
        $session = session();
        $date = date('d-m-y h:i:s');
        $CustomerModel = new CustomerModel();
        $data = [
            'customer_name' => $this->request->getVar('name'),
            'customer_email'  => $this->request->getVar('email'),
            'customer_contact'  => $this->request->getVar('contact'),
            'created_at'      => $date,
            'updated_at' =>$date,
            'mid' => $_SESSION['mid']
        ];
        $CustomerModel->insert($data);
        $session->setflashdata('successmsg',"User added successfully!");
        return $this->response->redirect(site_url('/users-list'));
    }    
    // delete user
    public function delete($id = null){
        $session = session();
        $CustomerModel = new CustomerModel();
        $data['user'] = $CustomerModel->where('cid', $id)->delete($id);
        $session->setflashdata('errormsg',"User deleted successfully!");
        return $this->response->redirect(site_url('/users-list'));
    }    
}