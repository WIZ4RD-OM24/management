<?php 
namespace App\Controllers;  
use CodeIgniter\Controller;
use App\Models\ManagerModel;
  
class ManagerSignUpController extends Controller
{
    public function index()
    {
        helper(['form']);
        $data = [];
        echo view('manager_signup', $data);
    }
  
    public function store()
    {
        helper(['form']);
        $rules = [
            'name'  => 'required|min_length[5]|max_length[50]',
            'email' => 'required|min_length[4]|max_length[100]|valid_email|is_unique[manager.manager_email]',
            'password'  => 'required|min_length[8]|max_length[50]',
            'confirmpassword'  => 'matches[password]'
        ];
          
        if($this->validate($rules)){
            $ManagerModel = new ManagerModel();
            $date = date('d-m-y h:i:s');
            $data = [
                'manager_name'     => $this->request->getVar('name'),
                'manager_email'    => $this->request->getVar('email'),
                'manager_password' => password_hash($this->request->getVar('password'), PASSWORD_DEFAULT),
                'contact'          => $this->request->getVar('contact'),
                'created_at'       => $date,
                'updated_at'       => $date
            ];
            $ManagerModel->save($data);
            return redirect()->to('/signin');
        }else{
            $data['validation'] = $this->validator;
            echo view('manager_signup', $data);
        }
          
    }
  
}