<?php 
namespace App\Controllers;  
use CodeIgniter\Controller;
use App\Models\ManagerModel;
  
class ManagerSignInController extends Controller
{
    public function index()
    {
        helper(['form']);
        echo view('manager_signin');
    } 
  
    public function loginAuth()
    {
        $session = session();
        $ManagerModel = new ManagerModel();
        $email = $this->request->getVar('email');
        $password = $this->request->getVar('password');
        
        $data = $ManagerModel->where('manager_email', $email)->first();
        
        if($data){
            $pass = $data['manager_password'];
            $authenticatePassword = password_verify($password, $pass);
            if($authenticatePassword){
                $ses_data = [
                    'id' => $data['mid'],
                    'name' => $data['manager_name'],
                    'email' => $data['manager_email'],
                    'isLoggedIn' => TRUE
                ];
                $_SESSION['mid'] = $data['mid'];
                $session->set($ses_data);
                return redirect()->to('/customers');
            
            }else{
                $session->setFlashdata('msg', 'Password is incorrect.');
                return redirect()->to('/signin');
            }
        }else{
            $session->setFlashdata('msg', 'Email does not exist.');
            return redirect()->to('/signin');
        }
    }
}