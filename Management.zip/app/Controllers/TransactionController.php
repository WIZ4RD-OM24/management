<?php
namespace App\Controllers;  
use CodeIgniter\Controller;
use App\Models\TransactionModel;
use App\Models\ManagerModel;
use App\Models\CustomerModel;


class TransactionController extends Controller
{
    public function index()
    {
        $TransactionModel = new TransactionModel();
        $CustomerModel = new CustomerModel();
       // $customer = $CustomerModel->where('cid', 'DESC');
        //echo $customer['customer_name'];
        $data['users'] = $TransactionModel->orderBy('transaction_id', 'DESC')->findAll();
       
  // echo  "<pre>";
     
//print_r($data['users']);
        
      

$i=0;

foreach($data['users'] as $single)
{
   // echo $single['cid'];

   $customer = $CustomerModel->where('cid', $single['cid'])->findAll();
 // print_r($customer);
  // $customer['customer_name'];

  //echo $customer[0]['customer_name'];
 // echo "<br>";
   $data['users'][$i]['cname']=$customer[0]['customer_name'];

  // print_r($data['users']);
$i++;
}
//print_r($data['users']);

     //   $data['users']['name']=
    //  print_r($data);
    return view('transactions_list', $data);
    }



    public function add()
    {   
        $session = session();
        $ManagerModel = new ManagerModel();
        $manager = $ManagerModel->find($_SESSION['mid']);
        $date = date('d-m-y h:i:s');
        $amount = $this->request->getVar('amount');
        $transactionType = $this->request->getVar('transaction_type');
        
        // updating funds
        if ($transactionType=="Debit" && $manager['funds']>$amount){
            $data = [
                'funds' => $manager['funds']-$amount
            ];
            $ManagerModel->update($_SESSION['mid'],$data);
            //entering record
            $TransactionModel = new TransactionModel();
            $data = [
                'cid' => $this->request->getVar('cname'),
                'type'  => $transactionType,
                'transaction_amount'  => $amount,
                'transaction_time'      => $date,
                'mid' => $_SESSION['mid']
            ];
            $TransactionModel->insert($data);
        }elseif($transactionType=="Credit"){
            $data = [
                'funds' => $manager['funds']+$amount
            ];
            $ManagerModel->update($_SESSION['mid'],$data);
            //entering record
            $TransactionModel = new TransactionModel();
            $data = [
                'cid' => $this->request->getVar('cname'),
                'type'  => $transactionType,
                'transaction_amount'  => $amount,
                'transaction_time'      => $date,
                'mid' => $_SESSION['mid']
            ];
            $TransactionModel->insert($data);
        }else{
            echo "Insufficient Funds!";
            return $this->response->redirect(site_url('/users-list'));
        }    
        
        $session->setflashdata('successmsg',"Transaction added successfully!");
        $data['users'] = $TransactionModel->orderBy('transaction_id', 'DESC')->findAll();

        return $this->response->redirect(site_url('/users-list'));
    }
    public function view()
    {
        return view('transactions_list');
    }
}
