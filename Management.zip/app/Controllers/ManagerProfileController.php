<?php 
namespace App\Controllers;  
use CodeIgniter\Controller;
  
class ManagerProfileController extends Controller
{
    public function index()
    {
        $session = session();
        return view('manager_dashboard');
    }
}